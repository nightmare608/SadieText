//
// Copyright 2025 Signal Messenger, LLC.
// SPDX-License-Identifier: AGPL-3.0-only
//

package org.signal.libsignal.net

import org.signal.libsignal.internal.CompletableFuture
import org.signal.libsignal.internal.Native
import org.signal.libsignal.internal.liftExceptions
import org.signal.libsignal.internal.mapWithCancellation
import org.signal.libsignal.metadata.SealedSessionCipher
import org.signal.libsignal.protocol.ServiceId
import org.signal.libsignal.zkgroup.groupsend.GroupSendFullToken

public class UnauthMessagesService(
  private val connection: UnauthenticatedChatConnection,
) {
  /**
   * Sends a multi-recipient message encrypted with Sealed Sender v2.
   *
   * Messages to accounts that have been unregistered will be dropped by the server and (if using
   * [MultiRecipientSendAuthorization.GroupSend]) reported in the resulting
   * [MultiRecipientMessageResponse].
   *
   * All exceptions are mapped into [RequestResult]; unexpected ones will be treated as
   * [RequestResult.ApplicationError]. A [RequestUnauthorizedException] means `auth` is not valid
   * for the recipients specified in `payload`; this cannot happen when `auth` is
   * [MultiRecipientSendAuthorization.Story]. A [MismatchedDeviceException] indicates the recipient
   * devices specified in `payload` are out of date in some way. (This is not a "partial success"
   * result; the message has not been sent to anybody.)
   *
   * @see [SealedSessionCipher.multiRecipientEncrypt]
   */
  public fun sendMultiRecipientMessage(
    payload: ByteArray,
    timestamp: Long,
    auth: MultiRecipientSendAuthorization,
    onlineOnly: Boolean,
    urgent: Boolean,
  ): CompletableFuture<RequestResult<MultiRecipientMessageResponse, MultiRecipientSendFailure>> =
    liftExceptions {
      connection
        .runWithContextAndConnectionHandles { asyncCtx, conn ->
          Native.UnauthenticatedChatConnection_send_multi_recipient_message(
            asyncCtx,
            conn,
            payload,
            timestamp,
            auth.groupSendTokenBytesOrNull(),
            onlineOnly,
            urgent,
          )
        }
    }.mapWithCancellation(
      onSuccess = { rawUnregisteredIds ->
        @Suppress("UNCHECKED_CAST") // https://youtrack.jetbrains.com/issue/KT-11948
        RequestResult.Success(MultiRecipientMessageResponse(rawUnregisteredIds as Array<ByteArray>))
      },
      onError = { err -> err.toRequestResult<MultiRecipientSendFailure>() },
    )

  /**
   * Sends a 1:1 message encrypted with Sealed Sender.
   *
   * All exceptions are mapped into [RequestResult]; unexpected ones will be treated as
   * [RequestResult.ApplicationError]. A [RequestUnauthorizedException] means `auth` is not valid
   * for `destination`; this cannot happen when `auth` is
   * [UserBasedSendAuthorization.Story]. A [MismatchedDeviceException] indicates the recipient
   * devices specified in `contents` are out of date in some way. (This is not a "partial success"
   * result; the message has not been sent to anybody.) A [ServiceIdNotFoundException] indicates the
   * destination account has been unregistered.
   *
   * @see [SealedSessionCipher.encrypt]
   */
  public fun sendMessage(
    destination: ServiceId,
    timestamp: Long,
    contents: List<SingleOutboundSealedSenderMessage>,
    auth: UserBasedSendAuthorization,
    onlineOnly: Boolean,
    urgent: Boolean,
  ): CompletableFuture<RequestResult<Unit, SealedSendFailure>> =
    liftExceptions {
      val deviceIds = IntArray(contents.size)
      val registrationIds = IntArray(contents.size)
      val messages = arrayOfNulls<ByteArray>(contents.size)

      contents.forEachIndexed { i, next ->
        deviceIds[i] = next.deviceId
        registrationIds[i] = next.registrationId
        messages[i] = next.message
      }

      connection
        .runWithContextAndConnectionHandles { asyncCtx, conn ->
          Native.UnauthenticatedChatConnection_send_message(
            asyncCtx,
            conn,
            destination.toServiceIdFixedWidthBinary(),
            timestamp,
            deviceIds,
            registrationIds,
            messages.requireNoNulls(),
            auth.rawKind(),
            auth.payloadBytesOrNull(),
            onlineOnly,
            urgent,
          )
        }
    }.mapWithCancellation(
      onSuccess = { _ -> RequestResult.Success(Unit) },
      onError = { err -> err.toRequestResult<SealedSendFailure>() },
    )
}

public sealed interface MultiRecipientSendAuthorization {
  public object Story : MultiRecipientSendAuthorization

  public data class GroupSend(
    public val token: GroupSendFullToken,
  ) : MultiRecipientSendAuthorization
}

/** Either [RequestUnauthorizedException] or [MismatchedDeviceException]. */
public sealed interface MultiRecipientSendFailure : BadRequestError

private fun MultiRecipientSendAuthorization.groupSendTokenBytesOrNull(): ByteArray? =
  when (this) {
    is MultiRecipientSendAuthorization.Story -> null
    is MultiRecipientSendAuthorization.GroupSend -> token.serialize()
  }

/**
 * Successful response for [UnauthMessagesService.sendMultiRecipientMessage].
 *
 * When sending using [MultiRecipientSendAuthorization.GroupSend], the server will report which
 * recipients are currently unregistered. For [MultiRecipientSendAuthorization.Story] the list will
 * always be empty.
 */
public class MultiRecipientMessageResponse(
  public val unregisteredIds: List<ServiceId>,
) {
  internal constructor(
    rawUnregisteredIds: Array<ByteArray>,
  ) : this(rawUnregisteredIds.map(ServiceId::parseFromFixedWidthBinary)) {}
}

/** Either [UserBasedAuthorization], or `UserBasedSendAuthorization.Story`. */
public sealed interface UserBasedSendAuthorization {
  public object Story : UserBasedSendAuthorization
}

// Must be kept in sync with `UserBasedSendAuthorizationKind` in Rust.
private fun UserBasedSendAuthorization.rawKind(): Int =
  when (this) {
    is UserBasedSendAuthorization.Story -> 0
    is UserBasedAuthorization.AccessKey -> 1
    is UserBasedAuthorization.GroupSend -> 2
    is UserBasedAuthorization.UnrestrictedUnauthenticatedAccess -> 3
  }

private fun UserBasedSendAuthorization.payloadBytesOrNull(): ByteArray? =
  when (this) {
    is UserBasedSendAuthorization.Story -> null
    is UserBasedAuthorization.AccessKey -> bytes
    is UserBasedAuthorization.GroupSend -> token.serialize()
    is UserBasedAuthorization.UnrestrictedUnauthenticatedAccess -> null
  }

/** Either [ServiceIdNotFoundException], [RequestUnauthorizedException] or [MismatchedDeviceException]. */
public sealed interface SealedSendFailure : BadRequestError
